import GariLanding from './GariLanding';

function App() {
  return <GariLanding />;
}

export default App;
