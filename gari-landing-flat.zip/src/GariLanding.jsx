import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function GariLanding() {
  const [email, setEmail] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Email enviado:", email);
  };

  return (
    <div className="min-h-screen bg-white text-gray-800 p-6">
      <section className="text-center py-20 max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">GARI: Encontrá y compartí lugares para estacionar</h1>
        <p className="text-lg mb-6">
          La app que conecta a conductores con personas que tienen cocheras o espacios libres en Castelar y zona oeste.
        </p>
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2 justify-center">
          <Input
            type="email"
            placeholder="Dejá tu email para ser de los primeros"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="max-w-xs"
            required
          />
          <Button type="submit">Unirme a la lista</Button>
        </form>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto py-12">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">¿Sos conductor?</h2>
            <ul className="list-disc pl-5 text-base text-gray-700 space-y-2">
              <li>Reservá lugar desde tu celular antes de llegar</li>
              <li>Pagá por minuto, sin sorpresas</li>
              <li>Más barato y seguro que girar sin parar</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">¿Tenés un espacio libre?</h2>
            <ul className="list-disc pl-5 text-base text-gray-700 space-y-2">
              <li>Publicá tu cochera, entrada o espacio libre</li>
              <li>Generá ingresos en tus horarios disponibles</li>
              <li>Cobrás fácil y sin comisiones ocultas</li>
            </ul>
          </CardContent>
        </Card>
      </section>

      <section className="bg-gray-100 py-12">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">¿Cómo funciona?</h2>
          <div className="grid md:grid-cols-3 gap-8 text-left">
            <div>
              <h3 className="text-xl font-semibold mb-2">1. Registrate</h3>
              <p>Creá tu cuenta con tus datos y empezá a usar la app como conductor o anfitrión.</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">2. Publicá o reservá</h3>
              <p>Si tenés un lugar libre, subilo. Si necesitás estacionar, buscá en el mapa y reservá.</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">3. Coordiná y listo</h3>
              <p>Usá el lugar reservado o recibí a un conductor. Todo desde la app, sin complicaciones.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="text-center py-16 max-w-xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Sé parte del lanzamiento</h2>
        <p className="mb-6">Estamos empezando en Castelar. Unite a la lista y enterate antes que nadie.</p>
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2 justify-center">
          <Input
            type="email"
            placeholder="Tu email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="max-w-xs"
            required
          />
          <Button type="submit">Unirme</Button>
        </form>
      </section>
    </div>
  );
}
