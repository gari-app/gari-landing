# GARI Landing Page

Este es el proyecto de la landing page para GARI, una app que conecta a conductores con personas que tienen espacios de estacionamiento disponibles.

## Cómo correrlo

```bash
npm install
npm run dev
```

Luego accedé a `http://localhost:5173`
